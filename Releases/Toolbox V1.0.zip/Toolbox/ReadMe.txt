make a shortcut here where the text file is

make the shortcut from Toolbox [MAIN].bat